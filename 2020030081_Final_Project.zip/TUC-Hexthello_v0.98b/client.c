#include "global.h"
#include "board.h"
#include "move.h"
#include "comm.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <limits.h>

#define MAX_DEPTH 3

/**********************************************************/
Position gamePosition;		// Position we are going to use

Move moveReceived;			// temporary move to retrieve opponent's choice
Move myMove;				// move to save our choice and send it to the server

char myColor;				// to store our color
int mySocket;				// our socket
char msg;					// used to store the received message

char * agentName = "Ermi!";		//default name.. change it! keep in mind MAX_NAME_LENGTH

char * ip = "127.0.0.1";	// default ip (local machine)
/**********************************************************/

// Get legal moves 	
int get_legal_moves(Position *pos, char myColor, Move possible_moves[]) {
    int numMoves = 0;

    for (int i = 0; i < ARRAY_BOARD_SIZE; i++) {
        for (int j = 0; j < ARRAY_BOARD_SIZE; j++) {
            Move move; 
            move.tile[0] = i;
            move.tile[1] = j;
            move.color = myColor; 

            if (isLegalMove(pos, &move)) {
                possible_moves[numMoves] = move;  
                numMoves++;
            }
        }
    }
    return numMoves;  
}

// The simplest evaluation function
//int evaluation_function(Position *pos, char myColor){
//	int myScore = 0;
//	int oppScore = 0;
//
//	for(int i =0; i < ARRAY_BOARD_SIZE; i++){
//		for(int j = 0; j < ARRAY_BOARD_SIZE; j++){
//			if(pos->board[i][j] == myColor){
//				myScore++;
//			}
//			else if(pos->board[i][j] == getOtherSide(myColor)){
//				oppScore++;
//			}
//		}
//	}
//
//	return myScore - oppScore;
//}

// Stability
int is_stable(Position *pos, int x, int y, char color){
    int directions[6][2] = {
        {-1, 0}, {1, 0},  
        {-1, 1}, {1, -1}, 
        {0, -1}, {0, 1} 
     };  

    for (int d = 0; d < 6; d++) {
        int nx = x + directions[d][0];
        int ny = y + directions[d][1];

        if (nx >= 0 && nx < ARRAY_BOARD_SIZE && ny >= 0 && ny < ARRAY_BOARD_SIZE) {
            if (pos->board[nx][ny] != color) {
                return 0;
            }
        }
    }

    return 1;
}

// Corner values
int is_corner(Position *gamePosition, char myColor) {
    
    int cornerPositions[6][2] = {  {0, ARRAY_BOARD_SIZE-1}, {(ARRAY_BOARD_SIZE-1)/2,0}, {(ARRAY_BOARD_SIZE-1)/2, ARRAY_BOARD_SIZE-1} ,
                                {0,(ARRAY_BOARD_SIZE-1)/2} ,{(ARRAY_BOARD_SIZE-1)/2, ARRAY_BOARD_SIZE-1} , {ARRAY_BOARD_SIZE-1,0}};  

    for (int i = 0; i < 6; i++) {
        int x = cornerPositions[i][0];
        int y = cornerPositions[i][1];
        if (gamePosition->board[x][y] == myColor) return 1;
    }

    return 0;
}

//More complex and optimized evaluation function that takes into consideration piece difference, mobility, stability, corner values
int evaluation_function(Position *pos, char myColor) {
    int myScore = 0;
    int oppScore = 0;

    int myMobility = 0;
    int oppMobility = 0;

    int myStability = 0;
    int oppStability = 0;

    int myCornerValue = 0;
    int oppCornerValue = 0;
    
    char oppColor = getOtherSide(myColor);
    Move myMoves[ARRAY_BOARD_SIZE * ARRAY_BOARD_SIZE];
    Move oppMoves[ARRAY_BOARD_SIZE * ARRAY_BOARD_SIZE];

    int myLegalMoves = get_legal_moves(pos, myColor, myMoves);
    int oppLegalMoves = get_legal_moves(pos, oppColor, oppMoves);
    
    // Mobility
    myMobility = myLegalMoves;
    oppMobility = oppLegalMoves;

    for (int i = 0; i < ARRAY_BOARD_SIZE; i++) {	
        for (int j = 0; j < ARRAY_BOARD_SIZE; j++) {
            char piece = pos->board[i][j];

            if (piece == myColor) {
                myScore++;

                if (is_stable(pos, i , j, myColor)){
                	myStability ++;
                }

                if(is_corner(pos,myColor)){
                	myCornerValue ++;
                } 
            } 
            else if (piece == oppColor) {
                oppScore++;
                if (is_stable(pos, i , j, oppColor)){
                	oppStability ++;
                }

                if(is_corner(pos,oppColor)){
                	oppCornerValue ++;
                }

            }
        }
    }

    // Piece difference
    int pieceValue = 5 * (myScore - oppScore); //10

    // Corner values (The most important one!!)
    int cornerValue = 30 * (myCornerValue - oppCornerValue); //30

    // Mobility
	int mobilityValue = 10 * (myMobility - oppMobility);  //20

	// Stability
	int stabilityValue = 2 * (myStability - oppStability);//10
  
    return pieceValue + mobilityValue + cornerValue + stabilityValue;
}


// Forward Pruning
int get_top_moves(Position *pos, char myColor, Move possible_moves[], int topN) {
    Move allMoves[ARRAY_BOARD_SIZE * ARRAY_BOARD_SIZE];
    int numMoves = get_legal_moves(pos, myColor, allMoves);
    
    if (numMoves <= topN) {
        memcpy(possible_moves, allMoves, numMoves * sizeof(Move));
        return numMoves;
    }

    int eval[numMoves];
    for (int i = 0; i < numMoves; i++) {
        Position newPos = *pos;
        doMove(&newPos, &allMoves[i]);
        eval[i] = evaluation_function(&newPos, myColor);
    }

    //sorting in descending order
    for (int i = 0; i < numMoves - 1; i++) {
        for (int j = i + 1; j < numMoves; j++) {
            if (eval[j] > eval[i]) {
                
                Move tempMove = allMoves[i];
                allMoves[i] = allMoves[j];
                allMoves[j] = tempMove;

                // Swap scores
                int tempEval = eval[i];
                eval[i] = eval[j];
                eval[j] = tempEval;
            }
        }
    }

    // Keep the best topN moves
    memcpy(possible_moves, allMoves, topN * sizeof(Move));
    return topN;
}

int minimax(Position *pos, int depth, char color, int alpha, int beta){
	if(depth == 0 || !canMove(pos,color)){
		return evaluation_function(pos,myColor);
	}

	int bestVal;
	Move possible_moves[ARRAY_BOARD_SIZE * ARRAY_BOARD_SIZE];
	int numMoves = get_legal_moves(pos, color, possible_moves);

	//Forward pruning
	//int numMoves = get_top_moves(pos, color, possible_moves, 5); 

	if(color == myColor){ //Maximizer
		bestVal = INT_MIN;
		for(int i = 0; i < numMoves; i++){
			Position newPos = *pos;
			doMove(&newPos, &possible_moves[i]);
			int value = minimax(&newPos, depth - 1, getOtherSide(color), alpha, beta);

			if(value >  bestVal){
				bestVal = value;
			}
			if(alpha < bestVal){
				alpha = bestVal;
			}

			if(beta <= alpha){
				break;
			}
		}
	}
	else{ //Minimizer
		bestVal = INT_MAX;
		for(int i = 0; i < numMoves; i++){
			Position newPos = *pos;
			doMove(&newPos, &possible_moves[i]);
			int value = minimax(&newPos, depth - 1, getOtherSide(color), alpha, beta);

			if(value < bestVal){
				bestVal = value;
			}
			if(beta > bestVal){
				beta = bestVal;
			}

			if(beta <= alpha){
				break;
			}
		}
	}
	return bestVal;
}


void choose_best_move(Position *pos, Move *bestMove){
	Move possible_moves[ARRAY_BOARD_SIZE * ARRAY_BOARD_SIZE];

	int numMoves = get_legal_moves(pos, myColor, possible_moves);

	int bestVal = INT_MIN;
	for(int i = 0; i < numMoves; i++){
		Position newPos = *pos;
		doMove(&newPos, &possible_moves[i]);
		int moveVal = minimax(&newPos, MAX_DEPTH, getOtherSide(myColor) ,INT_MIN, INT_MAX);

		if(moveVal > bestVal){
			bestVal = moveVal;
			*bestMove = possible_moves[i];
		}
	}
}

int main( int argc, char ** argv )
{
	int c;
	opterr = 0;

	while( ( c = getopt ( argc, argv, "i:p:h" ) ) != -1 )
		switch( c )
		{
			case 'h':
				printf( "[-i ip] [-p port]\n" );
				return 0;
			case 'i':
				ip = optarg;
				break;
			case 'p':
				port = optarg;
				break;
			case '?':
				if( optopt == 'i' || optopt == 'p' )
					printf( "Option -%c requires an argument.\n", ( char ) optopt );
				else if( isprint( optopt ) )
					printf( "Unknown option -%c\n", ( char ) optopt );
				else
					printf( "Unknown option character -%c\n", ( char ) optopt );
				return 1;
			default:
			return 1;
		}

	connectToTarget( port, ip, &mySocket );

/**********************************************************/
// used in random
	srand( time( NULL ) );
	int i, j;
/**********************************************************/

	while( 1 )
	{

		msg = recvMsg( mySocket );

		switch ( msg )
		{
			case NM_REQUEST_NAME:		//server asks for our name
				sendName( agentName, mySocket );
				break;

			case NM_NEW_POSITION:		//server is trying to send us a new position
				getPosition( &gamePosition, mySocket );
				printPosition( &gamePosition );
				break;

			case NM_COLOR_W:			//server informs us that we have WHITE color
				myColor = WHITE;
				break;

			case NM_COLOR_B:			//server informs us that we have BLACK color
				myColor = BLACK;
				break;

			case NM_PREPARE_TO_RECEIVE_MOVE:	//server informs us that he will now send us opponent's move
				getMove( &moveReceived, mySocket );
				moveReceived.color = getOtherSide( myColor );
				doMove( &gamePosition, &moveReceived );		//play opponent's move on our position
				printPosition( &gamePosition );
				break;

			case NM_REQUEST_MOVE:		//server requests our move
				myMove.color = myColor;


				if( !canMove( &gamePosition, myColor ) )
				{
					myMove.tile[ 0 ] = NULL_MOVE;		// we have no move ..so send null move
				}
				else
				{

					choose_best_move(&gamePosition, &myMove);
/**********************************************************/
// random player - not the most efficient implementation
//					while( 1 )
//					{
//						i = rand() % ARRAY_BOARD_SIZE;
//						j = rand() % ARRAY_BOARD_SIZE;
//
//						if( gamePosition.board[ i ][ j ] == EMPTY )
//						{
//							myMove.tile[ 0 ] = i;
//							myMove.tile[ 1 ] = j;
//							if( isLegalMove( &gamePosition, &myMove ) )
//								break;
//						}
//					}
//
// end of random
/**********************************************************/

				}

				sendMove( &myMove, mySocket );			//send our move
				doMove( &gamePosition, &myMove );		//play our move on our position
				printPosition( &gamePosition );
				break;

			case NM_QUIT:			//server wants us to quit...we shall obey
				close( mySocket );
				return 0;
		}
	} 

	return 0;
}





